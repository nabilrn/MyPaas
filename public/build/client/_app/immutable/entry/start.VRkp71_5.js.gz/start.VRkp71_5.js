import{l as o,b as r}from"../chunks/DOS1i2qW.js";export{o as load_css,r as start};
